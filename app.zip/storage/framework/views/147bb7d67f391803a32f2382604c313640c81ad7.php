
<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="main-title">Dashboard</h2>
    <div class="row">
        <div class="col">
            <div class="card my-card">
                <div class="card-header bg-primary text-white">
                    <strong><?php echo app('translator')->get('Users'); ?></strong>
                </div>
                <div class="card-body">
                    <div class="row mb-2">
                        <div class="col">
                            <button class="btn btn-success" data-toggle="modal" data-target="#add">Add new</button>
                        </div>
                        <div class="col">
                            <form action="<?php echo e(route('users.search')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="input-group col-sm-12 mb-3 float-end">
                                    <input type="text" class="form-control" name="keyword"
                                        placeholder="<?php echo app('translator')->get('Search'); ?>">
                                </div>
                            </form>
                        </div>
                    </div>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Group</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="col-2"><?php echo e($item->name); ?></td>
                                <td class="col-3"><?php echo e($item->email); ?></td>
                                <td class="col-3">
                                    <?php if($item->user_group_id == 1): ?>
                                    <span class="badge badge-pill btn-success text-white">Admin</span>
                                    <?php else: ?>
                                    <span class="badge badge-pill btn-secondary">User</span>
                                    <?php endif; ?>
                                </td>
                                <td class="col-3">
                                    <button class="edit btn-warning" data-object="<?php echo e($item); ?>" data-toggle="modal"
                                        data-target="#edit"><i class="fas fa-pen"></i></button>
                                    <button class="delete btn-danger" data-id="<?php echo e($item->id); ?>" data-toggle="modal"
                                        data-target="#delete"><i class="fas fa-trash"></i></button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p>No Data</p>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <?php echo e($items->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="add" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle"><?php echo app('translator')->get('Add'); ?></h5>
                <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="form1" class="form-ad" action="<?php echo e(route('users.store')); ?>" method="POST">
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label><?php echo app('translator')->get('User Group'); ?></label>
                        <select name="user_group_id" id="" class="form-control">
                            <option value="1">Admin</option>
                            <option value="2">User</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label><?php echo app('translator')->get('Name'); ?></label>
                        <input type="text" name="name" id="name" class="form-control" placeholder="<?php echo app('translator')->get('Name'); ?>"
                            required>
                    </div>
                    <div class="form-group">
                        <label><?php echo app('translator')->get('Email'); ?></label>
                        <input type="email" class="form-control" name="email" id="email" placeholder="<?php echo app('translator')->get('Email'); ?>"
                            required>
                    </div>
                    <div class="form-group">
                        <label><?php echo app('translator')->get('Password'); ?></label>
                        <input type="password" name="password" class="form-control" placeholder="<?php echo app('translator')->get('Password'); ?>">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <input type="submit" name="" class="btn btn-success" value="Save Changes">
                </div>
            </form>
        </div>
    </div>
</div>


<div class="modal fade" id="edit" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle"><?php echo app('translator')->get('Update'); ?></h5>
                <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="form2" class="form-ad" action="" method="POST">
                <div class="modal-body">
                    <?php echo method_field('put'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label><?php echo app('translator')->get('User Group'); ?></label>
                        <select name="user_group_id" id="user_group_id" class="form-control">
                            <option value="1">Admin</option>
                            <option value="2">User</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label><?php echo app('translator')->get('Name'); ?></label>
                        <input type="text" name="name" id="name" class="form-control" placeholder="<?php echo app('translator')->get('Name'); ?>"
                            required>
                    </div>
                    <div class="form-group">
                        <label><?php echo app('translator')->get('Email'); ?></label>
                        <input type="email" class="form-control" name="email" id="email" placeholder="<?php echo app('translator')->get('Email'); ?>"
                            required>
                    </div>
                    <div class="form-group">
                        <label><?php echo app('translator')->get('Password'); ?></label>
                        <input type="password" name="password" class="form-control" placeholder="<?php echo app('translator')->get('Password'); ?>">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <input type="submit" name="" class="btn btn-success" value="Save Changes">
                </div>
            </form>
        </div>
    </div>
</div>



<div class="modal fade" id="delete" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="form3" class="form-ad" action="" method="POST">
                <?php echo method_field('delete'); ?>
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <h5 class="modal-title" id="exampleModalLongTitle">Are You Sure?</h5>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
                    <input type="submit" name="" class="btn btn-danger" value="Yes">
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->startPush('scripts'); ?>
<script>
    $('#edit').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget)
        var data = button.data('object')
        var modal = $(this)
        modal.find('.modal-body #user_group_id').val(data.user_group_id)
        modal.find('.modal-body #name').val(data.name)
        modal.find('.modal-body #email').val(data.email)
        $("#form2").attr('action', '<?php echo e(url("/")); ?>/users/' + data.id);
    });
    $('#delete').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget)
        var id = button.data('id')
        var modal = $(this)
        $("#form3").attr('action', '<?php echo e(url("/")); ?>/users/' + id);
    });
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\expense\resources\views/users/index.blade.php ENDPATH**/ ?>