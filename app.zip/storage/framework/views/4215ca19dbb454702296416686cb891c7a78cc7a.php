
<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="main-title" Account Settings</h2>
        <div class="row stat-cards">
            <div class="card col-12">
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('users.update', ['user' => Auth::user()->id])); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                        <div class="row">
                            <div class="form-group col">
                                <label><?php echo app('translator')->get('Name'); ?></label>
                                <input type="text" name="name" id="name" class="form-control"
                                    placeholder="<?php echo app('translator')->get('Name'); ?>" value="<?php echo e(Auth::user()->name); ?>" required>
                            </div>
                            <div class="form-group col">
                                <label><?php echo app('translator')->get('Email'); ?></label>
                                <input type="email" class="form-control" name="email" id="email"
                                    value="<?php echo e(Auth::user()->email); ?>" placeholder="<?php echo app('translator')->get('Email'); ?>" required>
                            </div>
                            <div class="form-group col">
                                <label><?php echo app('translator')->get('Password'); ?></label>
                                <input type="password" name="password" class="form-control"
                                    placeholder="<?php echo app('translator')->get('Password'); ?>">
                            </div>
                            <input type="hidden" name="user_group_id" value="<?php echo e(Auth::user()->user_group_id); ?>">
                        </div>
                        <div class="row">
                            <div class="form-group col">
                                <button type="submit" class="btn btn-success">Update</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/css/datepicker.css" />
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
    $('.sum').keyup(function () {
        var sum = 0;
        $('.sum').each(function () {
            sum += Number($(this).val());
        });
        $('.total').val(sum);
    });

    var date = new Date();
    var today = new Date(date.getFullYear(), date.getMonth(), date.getDate());
    var optSimple = {
        format: 'dd-mm-yyyy',
        todayHighlight: true,
        orientation: 'bottom right',
        autoclose: true,
        startDate: '-6d',
        endDate: '0d'
    };
    $('.datepicker').datepicker(optSimple);
    $('.datepicker').datepicker('setDate', today);


</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\expense\resources\views/users/account.blade.php ENDPATH**/ ?>